//#include "oglv1.h"
#include <QApplication>
#include <QDialog>
#include <QtOpenGL/QGL>
#include <QRect>
#include <QThread>
#include <iostream>
#include <unistd.h>
#include <stdio.h>

// #include "u3cam/u3cammixer.h"
// #include "u3cam/u3capture.h"
// #include "u3test/lewndx1.h"
//#include <time.h>
#include "qopenglwidgettdp.h"
//#include "lsqu3mcapture/lsqu3mcapture.h"

#include "leobase/common_leo.h"

#define TdpanoWndTest
//#define IMX6SOC

#ifdef IMX6SOC
#include "mcimod/mcimod.h"
#endif



int main(int argc, char *argv[])
{
	QApplication a(argc, argv);


	int diswidth = 960;
	int disheight = 540;
	printf("argc = %d\n", argc);
	if(argc >= 3){
		sscanf(argv[1], "%d", &diswidth);
		sscanf(argv[2], "%d", &disheight);
	}
	printf("input para %d %d\n", diswidth, disheight);

//    printf("new serial\n");
//    WZSerialPort w;
//    printf("start\n");
//    string comname = "com7";

//    if (w.open(comname.c_str(),115200,0,8,1,0))
//    {
//        printf("%s open ok\n", comname.c_str());
//        string str = "helloworsdasadfgsdjhjshdfgvhjhjzxvjzhhcsdugdczxhjczsdhdhxghdgysdhhhhjjhdjhfvvld";
//        w.send(str.c_str());

//        while(0){
//        w.receive();
//        //Sleep(50);
//        }
//        w.close();
//    }
//    else{
//        printf("%s open failed\n", comname.c_str());
//    }


	QOpenGLWidgetTdp wndPano;
	QThread *thread = new QThread;

	if (!QGLFormat::hasOpenGL()){
        LOGE("no opengl");
		return 1;
	}
    else{
        LOGI("Opengl supportted.\n");
    }
    wndPano.setGeometry(QRect(QPoint(0, 0), QSize(diswidth, disheight)));
//	wndPano->setAutoFillBackground(false);
//	wndPano->setWindowFlags(Qt::FramelessWindowHint);
//	wndPano->setAttribute(Qt::WA_TranslucentBackground, true);


    ///set rtsp source
     FILE *strfp = fopen("./rtspinfo", "r");
     if(strfp != NULL){
         char line[1024];
         int linecnt = 0;
         int ccnt=0;
         while(!feof(strfp)){
             fgets(line, 1000, strfp);
             if(strlen(line) > 1){
                 //printf("[%d]:%s",linecnt, line);
                 linecnt++;
             }

             printf("=%d=%d [%d]=%s", ccnt++, strlen(line), linecnt-1,  line);


//             if(feof(strfp)){
//                 break;
//             }
             if(linecnt==4){//
                 break;
             }
         }
         fclose(strfp);
     }

   ///set rtsp source
    strfp = fopen("./rtspinfo", "r");
    if(strfp != NULL){
        char line[1024];
        int linecnt = 0;
        while(!feof(strfp)){
            fgets(line, 1000, strfp);
            if(strlen(line) > 1){
                printf("[%d]:%s",linecnt, line);

                wndPano.setSourceRtsp(linecnt, line);
                linecnt++;
            }
            if(linecnt==4){//
                break;
            }
        }
        fclose(strfp);
    }


    wndPano.show();
//	wndPano.showFullScreen();


#ifdef IMX6SOC
    Mcimod* mci = Mcimod::getInstance();
	if(!mci->open()){
	//if(!Mcimod::open()){
		LOGE("Openg Mcimod failed.\n");
		return 1;
	}
    mci->createTextureId();
	mci->gst_imx_egl_viv_sink_init_viv_direct_texture();
	//Mcimod::createTextureId();
	//mci->start();
//	mci->preview(true);
	//Mcimod::preview(true);
	QObject::connect(mci, SIGNAL(sendFourTexId(int, int, int, int)), &wndPano, SLOT(extFourTextureId(int, int,int,int)), Qt::QueuedConnection);
	QObject::connect(&wndPano, SIGNAL(startVideo()), mci, SLOT(shot()), Qt::QueuedConnection);
#endif

   LOGI("this is test step 1.\n");
	///@ 如果wx1内部没有新建tdpanownd，则可以 从主函数启动tdpanownd
//    wndPano = new QOpenGLWidgetTdp();

	return a.exec();
}
